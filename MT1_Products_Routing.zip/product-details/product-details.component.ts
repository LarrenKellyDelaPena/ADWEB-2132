import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
Product = [
    {
      id: "SHL0001",
      name: "Playstation",
      description: "A video game console developed by Sony."
    },
    {
      id: "SHL0002",
      name: "Plant",
      description: "A living organism of the kind exemplified by trees, shrubs, herbs, grasses, ferns, and mosses, typically growing in a permanent site, absorbing water and inorganic substances through its roots, and synthesizing nutrients in its leaves by photosynthesis using the green pigment chlorophyll."
    },
    {
      id: "SHL0003",
      name: "Sparkling Water",
      description: "A refreshing alternative to sodas, but is it any healthier? To make water “sparkling,” it's infused with carbon dioxide gas under pressure. Different forms of sparkling water include club soda (which often has added minerals), soda water, and seltzer water."
    },
    {
      id: "SHL0004",
      name: "Instant Camera",
      description: "A camera which uses self-developing film to create a chemically developed print shortly after taking the picture."
    },
    {
      id: "SHL0005",
      name: "Aerin Perfume",
      description: "A luxury fragrance brand inspired by the signature effortless style, aesthetic point of view, and heritage of its founder, Aerin Lauder."
    },
    {
      id: "SHL0006",
      name: "Table",
      description: "A piece of furniture with a flat top and one or more legs, providing a level surface on which objects may be placed, and that can be used for such purposes as eating, writing, working, or playing games."
    },
  ]
  constructor() { }

  ngOnInit(): void {
  }

}